"use client";

import { motion } from "framer-motion";
import { Check, Globe2, KeyRound, ShieldCheck, Sparkles, type LucideIcon } from "lucide-react";
import { FormEvent, useState } from "react";
import { api } from "@/lib/api";

const fields = [
  ["username", "Admin Username", "owner"],
  ["email", "Admin Email", "owner@example.com"],
  ["password", "Admin Password", "Strong password"],
  ["firstName", "First Name", "Alex"],
  ["lastName", "Last Name", "Heron"],
  ["domainUrl", "Domain URL", "https://panel.example.com"],
  ["panelName", "Panel Name", "HeronPanel"],
  ["timezone", "Timezone", "Asia/Calcutta"],
  ["language", "Language", "en"]
] as const;

type SetupPayload = Record<(typeof fields)[number][0], string> & {
  cloudflareTunnelCommand: string;
};

export function InstallerWizard({ onInstalled }: { onInstalled: () => void }) {
  const [form, setForm] = useState<SetupPayload>({
    username: "",
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    domainUrl: "",
    panelName: "HeronPanel",
    timezone: "Asia/Calcutta",
    language: "en",
    cloudflareTunnelCommand: ""
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      await api("/installer/setup", {
        method: "POST",
        body: JSON.stringify(form)
      });
      onInstalled();
    } catch (setupError) {
      setError(setupError instanceof Error ? setupError.message : "Setup failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen overflow-hidden px-4 py-6 sm:px-6 lg:px-10">
      <div className="mx-auto grid min-h-[calc(100vh-3rem)] max-w-7xl items-center gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="space-y-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-heron-line bg-white/5 px-4 py-2 text-sm text-cyan-100">
            <Sparkles size={16} className="text-heron-cyan" />
            Heron Premium Dark setup
          </div>
          <div className="space-y-5">
            <h1 className="max-w-3xl text-4xl font-semibold leading-tight text-white sm:text-6xl">
              HeronPanel
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-300">
              Premium Self-Hosted Server Management Platform with automatic node setup, secure defaults, and a polished dashboard from the first login.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {([
              ["Secure owner bootstrap", ShieldCheck],
              ["JWT and API keys", KeyRound],
              ["Domain ready", Globe2]
            ] as Array<[string, LucideIcon]>).map(([label, Icon]) => (
              <div key={label} className="glass rounded-lg p-4">
                <Icon className="mb-3 text-heron-cyan" size={22} />
                <p className="text-sm font-medium text-slate-100">{label}</p>
              </div>
            ))}
          </div>
        </section>

        <motion.form
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          onSubmit={submit}
          className="glass rounded-lg p-5 sm:p-6"
        >
          <div className="mb-6 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm uppercase tracking-[0.24em] text-heron-cyan">First run</p>
              <h2 className="mt-2 text-2xl font-semibold">Create owner account</h2>
            </div>
            <div className="rounded-lg border border-heron-line bg-white/5 p-3 text-heron-cyan">
              <Check size={24} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {fields.map(([name, label, placeholder]) => (
              <label key={name} className={name === "password" || name === "domainUrl" ? "sm:col-span-2" : ""}>
                <span className="mb-2 block text-sm font-medium text-slate-300">{label}</span>
                <input
                  required
                  type={name === "password" ? "password" : name === "email" ? "email" : "text"}
                  placeholder={placeholder}
                  value={form[name]}
                  onChange={(event) => setForm({ ...form, [name]: event.target.value })}
                  className="w-full rounded-lg border border-heron-line bg-black/25 px-4 py-3 text-white outline-none transition focus:border-heron-cyan focus:shadow-glow"
                />
              </label>
            ))}
            <label className="sm:col-span-2">
              <span className="mb-2 block text-sm font-medium text-slate-300">Cloudflare Tunnel Docker Command or Token</span>
              <textarea
                placeholder="docker run cloudflare/cloudflared:latest tunnel --no-autoupdate run --token YOUR_TOKEN"
                value={form.cloudflareTunnelCommand}
                onChange={(event) => setForm({ ...form, cloudflareTunnelCommand: event.target.value })}
                className="min-h-24 w-full rounded-lg border border-heron-line bg-black/25 px-4 py-3 text-white outline-none transition focus:border-heron-cyan focus:shadow-glow"
              />
            </label>
          </div>

          {error && <p className="mt-4 rounded-lg border border-red-400/30 bg-red-500/10 p-3 text-sm text-red-100">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="mt-6 w-full rounded-lg bg-cyan-300 px-5 py-3 font-semibold text-slate-950 shadow-glow transition hover:bg-white disabled:cursor-wait disabled:opacity-70"
          >
            {loading ? "Securing installation..." : "Complete setup"}
          </button>
        </motion.form>
      </div>
    </main>
  );
}
