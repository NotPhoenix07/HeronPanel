# Plugins

Plugins can extend HeronPanel through manifests, backend hooks, custom dashboard pages, API scopes, and theme assets.

A plugin manifest lives in `plugins/<plugin-name>/plugin.json`.

```json
{
  "name": "example-plugin",
  "version": "0.1.0",
  "entry": "server.js",
  "hooks": ["server.created"],
  "pages": [{ "path": "/plugins/example", "label": "Example" }],
  "permissions": ["servers.read"]
}
```

Planned hook families:

- `server.created`
- `server.deleted`
- `server.power.changed`
- `node.connected`
- `user.approved`
- `backup.completed`
- `invoice.paid`

The current API includes plugin registration and enable/disable routes so marketplace and local plugin loading can be added without reshaping the database.
