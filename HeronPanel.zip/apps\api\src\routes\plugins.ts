import { Router } from "express";
import { z } from "zod";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../security.js";

export const pluginRouter = Router();

pluginRouter.use(requireAuth, requireRole(["OWNER", "ADMIN"]));

pluginRouter.get("/", async (_request, response) => {
  const plugins = await prisma.plugin.findMany();
  response.json({ plugins });
});

pluginRouter.post("/", async (request, response) => {
  const input = z.object({
    name: z.string().min(2),
    version: z.string().min(1),
    manifest: z.record(z.unknown())
  }).parse(request.body);

  const plugin = await prisma.plugin.create({
    data: {
      name: input.name,
      version: input.version,
      manifest: JSON.stringify(input.manifest)
    }
  });

  response.status(201).json({ plugin });
});

pluginRouter.patch("/:id", async (request, response) => {
  const input = z.object({ enabled: z.boolean() }).parse(request.body);
  const plugin = await prisma.plugin.update({ where: { id: request.params.id }, data: input });
  response.json({ plugin });
});
