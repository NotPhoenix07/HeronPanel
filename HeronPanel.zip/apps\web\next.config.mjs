/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  typedRoutes: true,
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${process.env.API_URL || "http://api:4000"}/api/:path*`
      },
      {
        source: "/health",
        destination: `${process.env.API_URL || "http://api:4000"}/health`
      }
    ];
  }
};

export default nextConfig;
