import { Router } from "express";
import { nanoid } from "nanoid";
import { z } from "zod";
import { startCloudflareTunnel } from "../docker.js";
import { prisma } from "../prisma.js";
import { hashSecret } from "../security.js";

const setupSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  domainUrl: z.string().url(),
  panelName: z.string().min(2),
  timezone: z.string().min(2),
  language: z.string().min(2),
  cloudflareTunnelCommand: z.string().optional().default("")
});

export const installerRouter = Router();

installerRouter.get("/status", async (_request, response) => {
  const installed = await prisma.setting.findUnique({ where: { key: "installed" } });
  const panelName = await prisma.setting.findUnique({ where: { key: "panel_name" } });
  response.json({ installed: installed?.value === "true", panelName: panelName?.value || "HeronPanel" });
});

installerRouter.post("/setup", async (request, response) => {
  const existing = await prisma.setting.findUnique({ where: { key: "installed" } });
  if (existing?.value === "true") {
    response.status(409).json({ message: "Installer is already disabled" });
    return;
  }

  const input = setupSchema.parse(request.body);
  const passwordHash = await hashSecret(input.password);
  const apiSecret = nanoid(48);
  const nodeSecret = nanoid(48);

  const owner = await prisma.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        username: input.username,
        email: input.email,
        passwordHash,
        firstName: input.firstName,
        lastName: input.lastName,
        role: "OWNER",
        status: "ACTIVE",
        emailVerifiedAt: new Date()
      }
    });

    await tx.setting.createMany({
      data: [
        { key: "installed", value: "true" },
        { key: "panel_name", value: input.panelName },
        { key: "panel_url", value: input.domainUrl },
        { key: "timezone", value: input.timezone },
        { key: "language", value: input.language },
        { key: "cloudflare_tunnel_command", value: input.cloudflareTunnelCommand },
        { key: "api_bootstrap_secret", value: apiSecret },
        { key: "node_bootstrap_secret", value: nodeSecret },
        { key: "ssl_auto_detect", value: "true" }
      ]
    });

    await tx.auditLog.create({
      data: {
        actorId: user.id,
        action: "installer.completed",
        metadata: JSON.stringify({ panelName: input.panelName, domainUrl: input.domainUrl })
      }
    });

    return user;
  });

  let tunnel = "not_configured";
  if (input.cloudflareTunnelCommand.trim()) {
    try {
      await startCloudflareTunnel(input.cloudflareTunnelCommand);
      tunnel = "running";
    } catch (error) {
      tunnel = error instanceof Error ? error.message : "failed";
    }
  }

  response.status(201).json({ id: owner.id, message: "HeronPanel installed", tunnel });
});
