import { Router } from "express";
import { nanoid } from "nanoid";
import { z } from "zod";
import { startCloudflareTunnel } from "../docker.js";
import { prisma } from "../prisma.js";
import { hashSecret } from "../security.js";

const setupSchema = z.object({
  username: z.string().trim().min(2).max(32),
  email: z.string().email(),
  password: z.string().min(6),
  firstName: z.string().trim().min(1),
  lastName: z.string().trim().min(1),
  domainUrl: z.string().min(3).transform((value) => {
    const trimmed = value.trim();
    return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  }),
  panelName: z.string().trim().min(2),
  timezone: z.string().trim().min(1),
  language: z.string().trim().min(1),
  cloudflareTunnelCommand: z.string().optional().default("")
});

export const installerRouter = Router();

installerRouter.get("/status", async (_request, response) => {
  const installed = await prisma.setting.findUnique({ where: { key: "installed" } });
  const panelName = await prisma.setting.findUnique({ where: { key: "panel_name" } });
  response.json({ installed: installed?.value === "true", panelName: panelName?.value || "HeronPanel" });
});

installerRouter.post("/setup", async (request, response, next) => {
  try {
    const existing = await prisma.setting.findUnique({ where: { key: "installed" } });
    if (existing?.value === "true") {
      response.status(409).json({ message: "Installer is already disabled" });
      return;
    }

    const input = setupSchema.parse(request.body);
    const passwordHash = await hashSecret(input.password);
    const apiSecret = nanoid(48);
    const nodeSecret = nanoid(48);

    const owner = await prisma.$transaction(async (tx) => {
      const user = await tx.user.upsert({
        where: { email: input.email },
        update: {
          username: input.username,
          passwordHash,
          firstName: input.firstName,
          lastName: input.lastName,
          role: "OWNER",
          status: "ACTIVE",
          emailVerifiedAt: new Date()
        },
        create: {
          username: input.username,
          email: input.email,
          passwordHash,
          firstName: input.firstName,
          lastName: input.lastName,
          role: "OWNER",
          status: "ACTIVE",
          emailVerifiedAt: new Date()
        }
      });

      const settings = [
        ["installed", "true"],
        ["panel_name", input.panelName],
        ["panel_url", input.domainUrl],
        ["timezone", input.timezone],
        ["language", input.language],
        ["cloudflare_tunnel_command", input.cloudflareTunnelCommand],
        ["api_bootstrap_secret", apiSecret],
        ["node_bootstrap_secret", nodeSecret],
        ["ssl_auto_detect", "true"]
      ];

      for (const [key, value] of settings) {
        await tx.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
      }

      await tx.auditLog.create({
        data: {
          actorId: user.id,
          action: "installer.completed",
          metadata: JSON.stringify({ panelName: input.panelName, domainUrl: input.domainUrl })
        }
      });

      return user;
    });

    let tunnel = "not_configured";
    if (input.cloudflareTunnelCommand.trim()) {
      try {
        await startCloudflareTunnel(input.cloudflareTunnelCommand);
        tunnel = "running";
      } catch (error) {
        tunnel = error instanceof Error ? error.message : "failed";
        await prisma.setting.upsert({ where: { key: "cloudflare_tunnel_status" }, update: { value: tunnel }, create: { key: "cloudflare_tunnel_status", value: tunnel } });
      }
    }

    response.status(201).json({ id: owner.id, message: "HeronPanel installed", tunnel });
  } catch (error) {
    next(error);
  }
});
