import { Router } from "express";
import { z } from "zod";
import { deleteDockerServer, startDockerServer, stopDockerServer } from "../docker.js";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../security.js";

export const serverRouter = Router();

serverRouter.use(requireAuth);

serverRouter.get("/", async (request, response) => {
  const adminRoles = ["OWNER", "ADMIN", "MODERATOR"];
  const servers = await prisma.server.findMany({
    where: adminRoles.includes(request.user!.role) ? {} : { ownerId: request.user!.id },
    include: { owner: { select: { username: true, email: true } }, node: true }
  });
  response.json({ servers });
});

serverRouter.post("/", requireRole(["OWNER", "ADMIN", "RESELLER"]), async (request, response) => {
  const input = z.object({
    name: z.string().min(2),
    type: z.string().min(2),
    image: z.string().min(2),
    ownerId: z.string(),
    nodeId: z.string().optional().nullable(),
    memoryMb: z.number().int().positive(),
    diskMb: z.number().int().positive(),
    cpuPercent: z.number().int().positive(),
    bandwidthMb: z.number().int().positive()
  }).parse(request.body);

  const server = await prisma.server.create({ data: { ...input, nodeId: input.nodeId || null } });
  await prisma.auditLog.create({ data: { actorId: request.user!.id, action: "server.created", metadata: JSON.stringify({ id: server.id, name: server.name }) } });
  response.status(201).json({ server });
});

serverRouter.delete("/:id", requireRole(["OWNER", "ADMIN"]), async (request, response) => {
  await deleteDockerServer(request.params.id);
  await prisma.server.delete({ where: { id: request.params.id } });
  await prisma.auditLog.create({ data: { actorId: request.user!.id, action: "server.deleted", metadata: JSON.stringify({ id: request.params.id }) } });
  response.json({ deleted: true });
});

serverRouter.post("/:id/power", async (request, response) => {
  const input = z.object({ signal: z.enum(["start", "stop", "restart", "kill"]) }).parse(request.body);
  const server = await prisma.server.findUnique({ where: { id: request.params.id } });

  if (!server) {
    response.status(404).json({ message: "Server not found" });
    return;
  }

  if (!["OWNER", "ADMIN", "MODERATOR"].includes(request.user!.role) && server.ownerId !== request.user!.id) {
    response.status(403).json({ message: "Permission denied" });
    return;
  }

  if (input.signal === "start" || input.signal === "restart") {
    if (input.signal === "restart") await stopDockerServer(server.id);
    await startDockerServer(server);
    const updated = await prisma.server.update({ where: { id: server.id }, data: { status: "ONLINE" } });
    await prisma.auditLog.create({ data: { actorId: request.user!.id, action: "server.power.start", metadata: JSON.stringify({ id: server.id }) } });
    response.json({ server: updated, docker: "started" });
    return;
  }

  await stopDockerServer(server.id);
  const updated = await prisma.server.update({ where: { id: server.id }, data: { status: "OFFLINE" } });
  await prisma.auditLog.create({ data: { actorId: request.user!.id, action: "server.power.stop", metadata: JSON.stringify({ id: server.id }) } });
  response.json({ server: updated, docker: "stopped" });
});
