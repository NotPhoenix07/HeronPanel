import { Router } from "express";
import { z } from "zod";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../security.js";

export const serverRouter = Router();

serverRouter.use(requireAuth);

serverRouter.get("/", async (request, response) => {
  const adminRoles = ["OWNER", "ADMIN", "MODERATOR"];
  const servers = await prisma.server.findMany({
    where: adminRoles.includes(request.user!.role) ? {} : { ownerId: request.user!.id },
    include: { owner: { select: { username: true, email: true } }, node: true }
  });
  response.json({ servers });
});

serverRouter.post("/", requireRole(["OWNER", "ADMIN", "RESELLER"]), async (request, response) => {
  const input = z.object({
    name: z.string().min(2),
    type: z.string().min(2),
    image: z.string().min(2),
    ownerId: z.string(),
    nodeId: z.string().optional(),
    memoryMb: z.number().int().positive(),
    diskMb: z.number().int().positive(),
    cpuPercent: z.number().int().positive(),
    bandwidthMb: z.number().int().positive()
  }).parse(request.body);

  const server = await prisma.server.create({ data: input });
  response.status(201).json({ server });
});

serverRouter.post("/:id/power", async (request, response) => {
  const input = z.object({ signal: z.enum(["start", "stop", "restart", "kill"]) }).parse(request.body);
  const server = await prisma.server.findUnique({ where: { id: request.params.id } });

  if (!server) {
    response.status(404).json({ message: "Server not found" });
    return;
  }

  if (!["OWNER", "ADMIN", "MODERATOR"].includes(request.user!.role) && server.ownerId !== request.user!.id) {
    response.status(403).json({ message: "Permission denied" });
    return;
  }

  const status = input.signal === "start" ? "STARTING" : input.signal === "stop" || input.signal === "kill" ? "STOPPING" : "STARTING";
  const updated = await prisma.server.update({ where: { id: server.id }, data: { status } });
  response.json({ server: updated, queued: true });
});
