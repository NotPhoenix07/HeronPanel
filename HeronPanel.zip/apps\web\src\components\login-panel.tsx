"use client";

import { FormEvent, useState } from "react";
import { LockKeyhole, Mail, Shield } from "lucide-react";
import { api } from "@/lib/api";

export function LoginPanel({ onLogin }: { onLogin: (token: string) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      const result = await api<{ token: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      localStorage.setItem("heron_token", result.token);
      onLogin(result.token);
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center px-4 py-8">
      <form onSubmit={submit} className="glass w-full max-w-md rounded-lg p-6">
        <div className="mb-7 flex items-center gap-3">
          <div className="rounded-lg border border-heron-line bg-white/5 p-3 text-heron-cyan">
            <Shield size={26} />
          </div>
          <div>
            <h1 className="text-2xl font-semibold">HeronPanel</h1>
            <p className="text-sm text-slate-400">Secure control center login</p>
          </div>
        </div>

        <label className="mb-4 block">
          <span className="mb-2 block text-sm text-slate-300">Email</span>
          <div className="flex items-center gap-3 rounded-lg border border-heron-line bg-black/25 px-4 py-3 focus-within:border-heron-cyan">
            <Mail size={18} className="text-slate-500" />
            <input className="w-full bg-transparent outline-none" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </div>
        </label>

        <label className="mb-2 block">
          <span className="mb-2 block text-sm text-slate-300">Password</span>
          <div className="flex items-center gap-3 rounded-lg border border-heron-line bg-black/25 px-4 py-3 focus-within:border-heron-cyan">
            <LockKeyhole size={18} className="text-slate-500" />
            <input className="w-full bg-transparent outline-none" type="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </div>
        </label>

        <div className="mb-5 flex justify-between text-sm">
          <span className="text-slate-500">2FA ready</span>
          <button type="button" className="text-heron-cyan">Forgot password</button>
        </div>

        {error && <p className="mb-4 rounded-lg border border-red-400/30 bg-red-500/10 p-3 text-sm text-red-100">{error}</p>}

        <button className="w-full rounded-lg bg-cyan-300 px-5 py-3 font-semibold text-slate-950 shadow-glow transition hover:bg-white" disabled={loading}>
          {loading ? "Checking session..." : "Login"}
        </button>
      </form>
    </main>
  );
}
