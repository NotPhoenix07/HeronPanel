import "dotenv/config";
import Docker from "dockerode";
import { io } from "socket.io-client";

const apiUrl = process.env.HERON_API_URL || "http://localhost:4000";
const nodeId = process.env.HERON_NODE_ID || "local-dev-node";
const nodeToken = process.env.HERON_NODE_TOKEN || "development-node-token-change-me";
const docker = new Docker({ socketPath: process.env.DOCKER_SOCKET || "/var/run/docker.sock" });
const socket = io(apiUrl, { transports: ["websocket"] });

async function stats() {
  try {
    const info = await docker.info();
    return {
      cpu: info.NCPU,
      memory: Math.round((info.MemTotal || 0) / 1024 / 1024),
      containers: info.Containers,
      running: info.ContainersRunning
    };
  } catch {
    return { cpu: 0, memory: 0, containers: 0, running: 0 };
  }
}

async function heartbeat() {
  const payload = await stats();
  socket.emit("node:stats", { nodeId, stats: payload });

  await fetch(`${apiUrl}/api/nodes/${nodeId}/heartbeat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      token: nodeToken,
      stats: { cpu: payload.cpu, memory: payload.memory, disk: 0 }
    })
  }).catch(() => undefined);
}

socket.on("connect", () => {
  console.log(`Heron daemon connected to ${apiUrl}`);
});

setInterval(heartbeat, 15_000);
void heartbeat();
