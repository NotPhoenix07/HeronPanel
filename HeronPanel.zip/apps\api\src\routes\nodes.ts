import { Router } from "express";
import { z } from "zod";
import { prisma } from "../prisma.js";
import { hashSecret, requireAuth, requireRole, verifySecret } from "../security.js";

export const nodeRouter = Router();

nodeRouter.get("/", requireAuth, requireRole(["OWNER", "ADMIN", "MODERATOR"]), async (_request, response) => {
  const nodes = await prisma.node.findMany({ include: { servers: true } });
  response.json({ nodes });
});

nodeRouter.post("/", requireAuth, requireRole(["OWNER", "ADMIN"]), async (request, response) => {
  const input = z.object({
    name: z.string().min(2),
    fqdn: z.string().min(3),
    location: z.string().min(2),
    token: z.string().min(24),
    memoryMb: z.number().int().positive(),
    diskMb: z.number().int().positive(),
    cpuThreads: z.number().int().positive()
  }).parse(request.body);

  const node = await prisma.node.create({
    data: {
      name: input.name,
      fqdn: input.fqdn,
      location: input.location,
      tokenHash: await hashSecret(input.token),
      memoryMb: input.memoryMb,
      diskMb: input.diskMb,
      cpuThreads: input.cpuThreads
    }
  });

  response.status(201).json({ node });
});

nodeRouter.delete("/:id", requireAuth, requireRole(["OWNER", "ADMIN"]), async (request, response) => {
  await prisma.node.delete({ where: { id: request.params.id } });
  response.json({ deleted: true });
});

nodeRouter.post("/:id/heartbeat", async (request, response) => {
  const input = z.object({
    token: z.string().min(24),
    stats: z.object({
      cpu: z.number(),
      memory: z.number(),
      disk: z.number()
    })
  }).parse(request.body);

  const node = await prisma.node.findUnique({ where: { id: request.params.id } });
  if (!node) {
    response.status(404).json({ message: "Node not found" });
    return;
  }

  if (!(await verifySecret(input.token, node.tokenHash))) {
    response.status(401).json({ message: "Invalid node token" });
    return;
  }

  const updated = await prisma.node.update({
    where: { id: node.id },
    data: { lastSeenAt: new Date(), isActive: true }
  });

  response.json({ node: updated, accepted: true, stats: input.stats });
});
