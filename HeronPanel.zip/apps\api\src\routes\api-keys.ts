import { Router } from "express";
import { nanoid } from "nanoid";
import { z } from "zod";
import { prisma } from "../prisma.js";
import { hashSecret, requireAuth } from "../security.js";

export const apiKeyRouter = Router();

apiKeyRouter.use(requireAuth);

apiKeyRouter.get("/", async (request, response) => {
  const keys = await prisma.apiKey.findMany({
    where: { userId: request.user!.id },
    select: { id: true, name: true, scopes: true, createdAt: true }
  });
  response.json({ keys });
});

apiKeyRouter.post("/", async (request, response) => {
  const input = z.object({
    name: z.string().min(2),
    scopes: z.array(z.string()).default(["servers.read"])
  }).parse(request.body);
  const token = `hp_${nanoid(48)}`;
  const key = await prisma.apiKey.create({
    data: {
      name: input.name,
      scopes: JSON.stringify(input.scopes),
      keyHash: await hashSecret(token),
      userId: request.user!.id
    }
  });
  response.status(201).json({ key: { id: key.id, name: key.name, token } });
});
