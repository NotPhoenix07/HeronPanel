"use client";

import { motion } from "framer-motion";
import { Activity, Bell, Boxes, Cpu, Database, FileCode2, HardDrive, KeyRound, Layers3, LayoutDashboard, PlugZap, Server, Shield, Users, type LucideIcon } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const data = [
  { time: "00:00", cpu: 26, ram: 48 },
  { time: "04:00", cpu: 32, ram: 52 },
  { time: "08:00", cpu: 58, ram: 61 },
  { time: "12:00", cpu: 45, ram: 68 },
  { time: "16:00", cpu: 71, ram: 74 },
  { time: "20:00", cpu: 63, ram: 69 }
];

const nav: Array<[LucideIcon, string]> = [
  [LayoutDashboard, "Overview"],
  [Server, "Servers"],
  [Boxes, "Nodes"],
  [Users, "Users"],
  [FileCode2, "Files"],
  [Database, "Database"],
  [PlugZap, "Plugins"],
  [KeyRound, "API Keys"],
  [Shield, "Security"]
];

export function Dashboard() {
  return (
    <main className="min-h-screen lg:grid lg:grid-cols-[17rem_1fr]">
      <aside className="border-b border-heron-line bg-black/25 p-4 backdrop-blur lg:min-h-screen lg:border-b-0 lg:border-r">
        <div className="mb-8 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-lg border border-heron-line bg-cyan-300 font-black text-slate-950 shadow-glow">H</div>
          <div>
            <p className="font-semibold">HeronPanel</p>
            <p className="text-xs text-slate-400">Premium Dark</p>
          </div>
        </div>
        <nav className="flex gap-2 overflow-x-auto lg:block lg:space-y-1">
          {nav.map(([Icon, label]) => (
            <button key={label} className="flex min-w-max items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-slate-300 transition hover:bg-white/[0.08] hover:text-white lg:w-full">
              <Icon size={18} className={label === "Overview" ? "text-heron-cyan" : "text-slate-500"} />
              {label}
            </button>
          ))}
        </nav>
      </aside>

      <section className="p-4 sm:p-6 lg:p-8">
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.22em] text-heron-cyan">Control plane</p>
            <h1 className="mt-2 text-3xl font-semibold">Infrastructure Overview</h1>
          </div>
          <div className="flex items-center gap-2">
            <button className="rounded-lg border border-heron-line bg-white/5 p-3 text-slate-200 hover:text-heron-cyan" aria-label="Notifications">
              <Bell size={18} />
            </button>
            <button className="rounded-lg bg-cyan-300 px-4 py-3 text-sm font-semibold text-slate-950 shadow-glow">Create Server</button>
          </div>
        </header>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {([
              ["Total Users", "128", Users, "+12 this week"],
              ["Total Servers", "342", Server, "291 online"],
              ["Active Nodes", "18", Boxes, "4 regions"],
              ["Revenue", "$8,420", Activity, "+18.4%"]
            ] as Array<[string, string, LucideIcon, string]>).map(([label, value, Icon, meta]) => (
            <motion.div key={label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-lg p-5">
              <div className="mb-4 flex items-center justify-between">
                <p className="text-sm text-slate-400">{label}</p>
                <Icon size={20} className="text-heron-cyan" />
              </div>
              <p className="text-3xl font-semibold">{value}</p>
              <p className="mt-2 text-sm text-slate-400">{meta}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-4 grid gap-4 xl:grid-cols-[1.35fr_0.65fr]">
          <section className="glass rounded-lg p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold">Live Resource Flow</h2>
                <p className="text-sm text-slate-400">CPU and memory telemetry across connected nodes</p>
              </div>
              <Cpu className="text-heron-cyan" />
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="cpu" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="5%" stopColor="#30e7ff" stopOpacity={0.55} />
                      <stop offset="95%" stopColor="#30e7ff" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="ram" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.45} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip contentStyle={{ background: "#08111f", border: "1px solid rgba(120,170,255,.2)", borderRadius: 8 }} />
                  <Area dataKey="cpu" stroke="#30e7ff" fill="url(#cpu)" strokeWidth={2} />
                  <Area dataKey="ram" stroke="#8b5cf6" fill="url(#ram)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="glass rounded-lg p-5">
            <h2 className="mb-4 text-xl font-semibold">Node Automation</h2>
            <div className="space-y-3">
              {([
                [Layers3, "Auto node bootstrap", "Install daemon, Docker, firewall rules, and secure token."],
                [HardDrive, "Backups", "Snapshot schedules with restore points."],
                [Shield, "Security guard", "Rate limits, audit logs, blacklist, and session history."]
              ] as Array<[LucideIcon, string, string]>).map(([Icon, title, body]) => (
                <div key={title} className="rounded-lg border border-heron-line bg-white/[0.03] p-4">
                  <Icon className="mb-3 text-heron-cyan" size={20} />
                  <p className="font-medium">{title}</p>
                  <p className="mt-1 text-sm leading-6 text-slate-400">{body}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <section className="glass mt-4 rounded-lg p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">Console Preview</h2>
            <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-xs text-emerald-200">online</span>
          </div>
          <pre className="no-scrollbar overflow-x-auto rounded-lg border border-heron-line bg-black/50 p-4 text-sm leading-7 text-cyan-100">
            {"> heron server start minecraft-01\n[daemon] pulling ghcr.io/heronpanel/java:21\n[container] resources: 4096MB RAM, 200% CPU, 25GB disk\n[console] Server marked online and websocket stream attached"}
          </pre>
        </section>
      </section>
    </main>
  );
}
