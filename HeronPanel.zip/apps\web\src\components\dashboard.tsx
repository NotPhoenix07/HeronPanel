"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Activity, Bell, Boxes, Cpu, Database, FileCode2, KeyRound, LayoutDashboard, PlugZap, Plus, Power, RefreshCcw, Server, Shield, Trash2, Users, type LucideIcon } from "lucide-react";
import { api } from "@/lib/api";

type Tab = "Overview" | "Servers" | "Nodes" | "Users" | "Files" | "Database" | "Plugins" | "API Keys" | "Security";

type Summary = { users: number; servers: number; nodes: number; plugins: number; activeUsers: number; onlineServers: number; activeNodes: number; revenue: number };
type User = { id: string; username: string; email: string; firstName: string; lastName: string; role: string; status: string; createdAt: string };
type NodeItem = { id: string; name: string; fqdn: string; location: string; memoryMb: number; diskMb: number; cpuThreads: number; isActive: boolean; lastSeenAt?: string; servers?: unknown[] };
type ServerItem = { id: string; name: string; type: string; image: string; status: string; memoryMb: number; diskMb: number; cpuPercent: number; bandwidthMb: number; owner?: { username: string; email: string }; node?: NodeItem | null };
type Plugin = { id: string; name: string; version: string; enabled: boolean; manifest: string };
type ApiKey = { id: string; name: string; scopes: string; createdAt: string };
type DatabaseInfo = { provider: string; tables: Array<{ name: string; records: number }> };
type SecurityInfo = { pendingUsers: number; bannedUsers: number; auditLogs: Array<{ id: string; action: string; metadata?: string; createdAt: string; actor?: { username: string } }>; sessions: Array<{ id: string; ip?: string; userAgent?: string; createdAt: string; user?: { username: string } }> };

const nav: Array<[LucideIcon, Tab]> = [
  [LayoutDashboard, "Overview"],
  [Server, "Servers"],
  [Boxes, "Nodes"],
  [Users, "Users"],
  [FileCode2, "Files"],
  [Database, "Database"],
  [PlugZap, "Plugins"],
  [KeyRound, "API Keys"],
  [Shield, "Security"]
];

const blankSummary: Summary = { users: 0, servers: 0, nodes: 0, plugins: 0, activeUsers: 0, onlineServers: 0, activeNodes: 0, revenue: 0 };

export function Dashboard() {
  const [active, setActive] = useState<Tab>("Overview");
  const [token] = useState(() => (typeof window === "undefined" ? "" : localStorage.getItem("heron_token") || ""));
  const [summary, setSummary] = useState<Summary>(blankSummary);
  const [users, setUsers] = useState<User[]>([]);
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [nodes, setNodes] = useState<NodeItem[]>([]);
  const [plugins, setPlugins] = useState<Plugin[]>([]);
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [database, setDatabase] = useState<DatabaseInfo | null>(null);
  const [security, setSecurity] = useState<SecurityInfo | null>(null);
  const [message, setMessage] = useState("");

  const authHeaders = useMemo(() => ({ Authorization: `Bearer ${token}` }), [token]);

  const loadAll = useCallback(async (currentToken = token) => {
    if (!currentToken) return;
    const headers = { Authorization: `Bearer ${currentToken}` };
    const [summaryResult, usersResult, serversResult, nodesResult, pluginsResult, keysResult, dbResult, securityResult] = await Promise.allSettled([
      api<Summary>("/admin/summary", { headers }),
      api<{ users: User[] }>("/users", { headers }),
      api<{ servers: ServerItem[] }>("/servers", { headers }),
      api<{ nodes: NodeItem[] }>("/nodes", { headers }),
      api<{ plugins: Plugin[] }>("/plugins", { headers }),
      api<{ keys: ApiKey[] }>("/api-keys", { headers }),
      api<DatabaseInfo>("/admin/database", { headers }),
      api<SecurityInfo>("/admin/security", { headers })
    ]);

    if (summaryResult.status === "fulfilled") setSummary(summaryResult.value);
    if (usersResult.status === "fulfilled") setUsers(usersResult.value.users);
    if (serversResult.status === "fulfilled") setServers(serversResult.value.servers);
    if (nodesResult.status === "fulfilled") setNodes(nodesResult.value.nodes);
    if (pluginsResult.status === "fulfilled") setPlugins(pluginsResult.value.plugins);
    if (keysResult.status === "fulfilled") setKeys(keysResult.value.keys);
    if (dbResult.status === "fulfilled") setDatabase(dbResult.value);
    if (securityResult.status === "fulfilled") setSecurity(securityResult.value);
  }, [token]);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  async function action<T>(work: () => Promise<T>, success: string) {
    setMessage("");
    try {
      await work();
      setMessage(success);
      await loadAll();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Action failed");
    }
  }

  return (
    <main className="min-h-screen lg:grid lg:grid-cols-[17rem_1fr]">
      <aside className="border-b border-heron-line bg-black/25 p-4 backdrop-blur lg:min-h-screen lg:border-b-0 lg:border-r">
        <div className="mb-8 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-lg border border-heron-line bg-cyan-300 font-black text-slate-950 shadow-glow">H</div>
          <div>
            <p className="font-semibold">HeronPanel</p>
            <p className="text-xs text-slate-400">Working Admin Panel</p>
          </div>
        </div>
        <nav className="flex gap-2 overflow-x-auto lg:block lg:space-y-1">
          {nav.map(([Icon, label]) => (
            <button key={label} onClick={() => setActive(label)} className={`flex min-w-max items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition lg:w-full ${active === label ? "bg-cyan-300 text-slate-950" : "text-slate-300 hover:bg-white/[0.08] hover:text-white"}`}>
              <Icon size={18} />
              {label}
            </button>
          ))}
        </nav>
      </aside>

      <section className="p-4 sm:p-6 lg:p-8">
        <header className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.22em] text-heron-cyan">Control plane</p>
            <h1 className="mt-2 text-3xl font-semibold">{active}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => void loadAll()} className="rounded-lg border border-heron-line bg-white/5 p-3 text-slate-200 hover:text-heron-cyan" aria-label="Refresh">
              <RefreshCcw size={18} />
            </button>
            <button className="rounded-lg border border-heron-line bg-white/5 p-3 text-slate-200" aria-label="Notifications">
              <Bell size={18} />
            </button>
          </div>
        </header>

        {message && <p className="mb-4 rounded-lg border border-heron-line bg-white/[0.05] p-3 text-sm text-cyan-100">{message}</p>}

        {active === "Overview" && <Overview summary={summary} />}
        {active === "Servers" && <Servers servers={servers} users={users} nodes={nodes} headers={authHeaders} action={action} />}
        {active === "Nodes" && <Nodes nodes={nodes} headers={authHeaders} action={action} />}
        {active === "Users" && <UsersView users={users} headers={authHeaders} action={action} />}
        {active === "Files" && <Files servers={servers} headers={authHeaders} />}
        {active === "Database" && <DatabaseView database={database} />}
        {active === "Plugins" && <Plugins plugins={plugins} headers={authHeaders} action={action} />}
        {active === "API Keys" && <ApiKeys keys={keys} headers={authHeaders} action={action} />}
        {active === "Security" && <SecurityView security={security} />}
      </section>
    </main>
  );
}

function Overview({ summary }: { summary: Summary }) {
  const cards: Array<[string, string, LucideIcon, string]> = [
    ["Total Users", String(summary.users), Users, `${summary.activeUsers} active`],
    ["Total Servers", String(summary.servers), Server, `${summary.onlineServers} online`],
    ["Active Nodes", String(summary.nodes), Boxes, `${summary.activeNodes} active`],
    ["Plugins", String(summary.plugins), Activity, "installed plugins"]
  ];

  return (
    <>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map(([label, value, Icon, meta]) => (
          <div key={label} className="glass rounded-lg p-5">
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm text-slate-400">{label}</p>
              <Icon size={20} className="text-heron-cyan" />
            </div>
            <p className="text-3xl font-semibold">{value}</p>
            <p className="mt-2 text-sm text-slate-400">{meta}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-4 xl:grid-cols-[1.35fr_0.65fr]">
        <section className="glass rounded-lg p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">Real Runtime Status</h2>
            <Cpu className="text-heron-cyan" />
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg border border-heron-line bg-white/[0.03] p-4">
              <p className="text-sm text-slate-400">Online containers</p>
              <p className="mt-2 text-3xl font-semibold">{summary.onlineServers}</p>
            </div>
            <div className="rounded-lg border border-heron-line bg-white/[0.03] p-4">
              <p className="text-sm text-slate-400">Registered nodes</p>
              <p className="mt-2 text-3xl font-semibold">{summary.nodes}</p>
            </div>
            <div className="rounded-lg border border-heron-line bg-white/[0.03] p-4">
              <p className="text-sm text-slate-400">Active users</p>
              <p className="mt-2 text-3xl font-semibold">{summary.activeUsers}</p>
            </div>
          </div>
        </section>
        <section className="glass rounded-lg p-5">
          <h2 className="mb-4 text-xl font-semibold">Working Modules</h2>
          {["Servers: create, power, delete", "Nodes: register, heartbeat-ready, delete", "Users: create, approve, suspend, ban", "Plugins/API keys: create, toggle, delete"].map((line) => (
            <p key={line} className="mb-3 rounded-lg border border-heron-line bg-white/[0.03] p-3 text-sm text-slate-300">{line}</p>
          ))}
        </section>
      </div>
    </>
  );
}

function Servers({ servers, users, nodes, headers, action }: { servers: ServerItem[]; users: User[]; nodes: NodeItem[]; headers: HeadersInit; action: <T>(work: () => Promise<T>, success: string) => Promise<void> }) {
  const [form, setForm] = useState({ name: "", type: "Minecraft", image: "itzg/minecraft-server:java21", ownerId: "", nodeId: "", memoryMb: "1024", diskMb: "5120", cpuPercent: "100", bandwidthMb: "10240" });

  async function submit(event: FormEvent) {
    event.preventDefault();
    await action(() => api("/servers", { method: "POST", headers, body: JSON.stringify({ ...form, ownerId: form.ownerId || users[0]?.id, memoryMb: Number(form.memoryMb), diskMb: Number(form.diskMb), cpuPercent: Number(form.cpuPercent), bandwidthMb: Number(form.bandwidthMb), nodeId: form.nodeId || null }) }), "Server created");
  }

  return <CrudLayout title="Create Server" form={<form onSubmit={submit} className="grid gap-3 md:grid-cols-2">{input("Name", form.name, (v) => setForm({ ...form, name: v }))}{select("Owner", form.ownerId, users.map((u) => [u.id, u.username]), (v) => setForm({ ...form, ownerId: v }))}{select("Node", form.nodeId, [["", "No node"], ...nodes.map((n) => [n.id, n.name] as [string, string])], (v) => setForm({ ...form, nodeId: v }))}{input("Type", form.type, (v) => setForm({ ...form, type: v }))}{input("Image", form.image, (v) => setForm({ ...form, image: v }))}{input("RAM MB", form.memoryMb, (v) => setForm({ ...form, memoryMb: v }), "number")}{input("Disk MB", form.diskMb, (v) => setForm({ ...form, diskMb: v }), "number")}{input("CPU %", form.cpuPercent, (v) => setForm({ ...form, cpuPercent: v }), "number")}<button className="rounded-lg bg-cyan-300 px-4 py-3 font-semibold text-slate-950"><Plus size={16} className="inline" /> Create</button></form>}>
    <Table headers={["Name", "Owner", "Node", "Resources", "Status", "Actions"]} rows={servers.map((server) => [server.name, server.owner?.username || "-", server.node?.name || "-", `${server.memoryMb}MB / ${server.cpuPercent}% CPU`, server.status, <RowActions key={server.id} actions={[["Start", Power, () => action(() => api(`/servers/${server.id}/power`, { method: "POST", headers, body: JSON.stringify({ signal: "start" }) }), "Server started")], ["Stop", Power, () => action(() => api(`/servers/${server.id}/power`, { method: "POST", headers, body: JSON.stringify({ signal: "stop" }) }), "Server stopped")], ["Delete", Trash2, () => action(() => api(`/servers/${server.id}`, { method: "DELETE", headers }), "Server deleted")]]} />])} />
  </CrudLayout>;
}

function Nodes({ nodes, headers, action }: { nodes: NodeItem[]; headers: HeadersInit; action: <T>(work: () => Promise<T>, success: string) => Promise<void> }) {
  const [form, setForm] = useState({ name: "", fqdn: "", location: "India", token: "change-this-node-token-123456", memoryMb: "4096", diskMb: "51200", cpuThreads: "2" });
  async function submit(event: FormEvent) {
    event.preventDefault();
    await action(() => api("/nodes", { method: "POST", headers, body: JSON.stringify({ ...form, memoryMb: Number(form.memoryMb), diskMb: Number(form.diskMb), cpuThreads: Number(form.cpuThreads) }) }), "Node registered");
  }
  return <CrudLayout title="Register Node" form={<form onSubmit={submit} className="grid gap-3 md:grid-cols-2">{input("Name", form.name, (v) => setForm({ ...form, name: v }))}{input("FQDN/IP", form.fqdn, (v) => setForm({ ...form, fqdn: v }))}{input("Location", form.location, (v) => setForm({ ...form, location: v }))}{input("Token", form.token, (v) => setForm({ ...form, token: v }))}{input("RAM MB", form.memoryMb, (v) => setForm({ ...form, memoryMb: v }), "number")}{input("Disk MB", form.diskMb, (v) => setForm({ ...form, diskMb: v }), "number")}{input("CPU Threads", form.cpuThreads, (v) => setForm({ ...form, cpuThreads: v }), "number")}<button className="rounded-lg bg-cyan-300 px-4 py-3 font-semibold text-slate-950">Register</button></form>}>
    <Table headers={["Name", "FQDN", "Location", "Capacity", "Status", "Actions"]} rows={nodes.map((node) => [node.name, node.fqdn, node.location, `${node.memoryMb}MB / ${node.diskMb}MB`, node.isActive ? "ACTIVE" : "OFFLINE", <RowActions key={node.id} actions={[["Delete", Trash2, () => action(() => api(`/nodes/${node.id}`, { method: "DELETE", headers }), "Node deleted")]]} />])} />
  </CrudLayout>;
}

function UsersView({ users, headers, action }: { users: User[]; headers: HeadersInit; action: <T>(work: () => Promise<T>, success: string) => Promise<void> }) {
  const [form, setForm] = useState({ username: "", email: "", password: "Password123!", firstName: "", lastName: "", role: "USER" });
  async function submit(event: FormEvent) {
    event.preventDefault();
    await action(() => api("/users", { method: "POST", headers, body: JSON.stringify(form) }), "User created");
  }
  return <CrudLayout title="Create User" form={<form onSubmit={submit} className="grid gap-3 md:grid-cols-2">{input("Username", form.username, (v) => setForm({ ...form, username: v }))}{input("Email", form.email, (v) => setForm({ ...form, email: v }), "email")}{input("Password", form.password, (v) => setForm({ ...form, password: v }))}{input("First name", form.firstName, (v) => setForm({ ...form, firstName: v }))}{input("Last name", form.lastName, (v) => setForm({ ...form, lastName: v }))}{select("Role", form.role, ["OWNER", "ADMIN", "MODERATOR", "RESELLER", "USER"].map((r) => [r, r]), (v) => setForm({ ...form, role: v }))}<button className="rounded-lg bg-cyan-300 px-4 py-3 font-semibold text-slate-950">Create</button></form>}>
    <Table headers={["Username", "Email", "Role", "Status", "Actions"]} rows={users.map((user) => [user.username, user.email, user.role, user.status, <RowActions key={user.id} actions={["ACTIVE", "SUSPENDED", "BANNED"].map((status) => [status, Shield, () => action(() => api(`/users/${user.id}/status`, { method: "PATCH", headers, body: JSON.stringify({ status }) }), `User ${status.toLowerCase()}`)] as [string, LucideIcon, () => void])} />])} />
  </CrudLayout>;
}

function Plugins({ plugins, headers, action }: { plugins: Plugin[]; headers: HeadersInit; action: <T>(work: () => Promise<T>, success: string) => Promise<void> }) {
  const [form, setForm] = useState({ name: "", version: "0.1.0" });
  async function submit(event: FormEvent) {
    event.preventDefault();
    await action(() => api("/plugins", { method: "POST", headers, body: JSON.stringify({ ...form, manifest: { hooks: [], pages: [] } }) }), "Plugin registered");
  }
  return <CrudLayout title="Register Plugin" form={<form onSubmit={submit} className="grid gap-3 md:grid-cols-3">{input("Name", form.name, (v) => setForm({ ...form, name: v }))}{input("Version", form.version, (v) => setForm({ ...form, version: v }))}<button className="rounded-lg bg-cyan-300 px-4 py-3 font-semibold text-slate-950">Register</button></form>}>
    <Table headers={["Name", "Version", "Enabled", "Actions"]} rows={plugins.map((plugin) => [plugin.name, plugin.version, plugin.enabled ? "YES" : "NO", <RowActions key={plugin.id} actions={[["Toggle", PlugZap, () => action(() => api(`/plugins/${plugin.id}`, { method: "PATCH", headers, body: JSON.stringify({ enabled: !plugin.enabled }) }), "Plugin updated")], ["Delete", Trash2, () => action(() => api(`/plugins/${plugin.id}`, { method: "DELETE", headers }), "Plugin deleted")]]} />])} />
  </CrudLayout>;
}

function ApiKeys({ keys, headers, action }: { keys: ApiKey[]; headers: HeadersInit; action: <T>(work: () => Promise<T>, success: string) => Promise<void> }) {
  const [name, setName] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault();
    await action(() => api("/api-keys", { method: "POST", headers, body: JSON.stringify({ name, scopes: ["servers.read", "servers.power"] }) }), "API key created. Raw token is returned once in API response.");
  }
  return <CrudLayout title="Create API Key" form={<form onSubmit={submit} className="grid gap-3 md:grid-cols-3">{input("Name", name, setName)}<button className="rounded-lg bg-cyan-300 px-4 py-3 font-semibold text-slate-950">Create Key</button></form>}>
    <Table headers={["Name", "Scopes", "Created"]} rows={keys.map((key) => [key.name, key.scopes, new Date(key.createdAt).toLocaleString()])} />
  </CrudLayout>;
}

function Files({ servers, headers }: { servers: ServerItem[]; headers: HeadersInit }) {
  const [serverId, setServerId] = useState("");
  const [files, setFiles] = useState<Array<{ name: string; type: string; size: number; permissions: string }>>([]);
  async function loadFiles(id: string) {
    setServerId(id);
    if (!id) return;
    const result = await api<{ files: typeof files }>(`/files/${id}`, { headers });
    setFiles(result.files);
  }
  return <section className="glass rounded-lg p-5"><h2 className="mb-4 text-xl font-semibold">File Manager</h2>{select("Server", serverId, [["", "Select server"], ...servers.map((s) => [s.id, s.name] as [string, string])], (v) => void loadFiles(v))}<Table headers={["Name", "Type", "Size", "Permissions"]} rows={files.map((file) => [file.name, file.type, `${file.size} bytes`, file.permissions])} /><p className="mt-4 text-sm text-slate-400">Upload/edit/delete wiring is daemon-ready. Real disk operations need the node daemon connected to server storage.</p></section>;
}

function DatabaseView({ database }: { database: DatabaseInfo | null }) {
  return <section className="glass rounded-lg p-5"><h2 className="mb-4 text-xl font-semibold">Database Manager</h2><p className="mb-4 text-sm text-slate-400">Provider: {database?.provider || "loading"}</p><Table headers={["Table", "Records"]} rows={(database?.tables || []).map((table) => [table.name, String(table.records)])} /></section>;
}

function SecurityView({ security }: { security: SecurityInfo | null }) {
  return <div className="grid gap-4 xl:grid-cols-2"><section className="glass rounded-lg p-5"><h2 className="mb-4 text-xl font-semibold">Audit Logs</h2><Table headers={["Action", "Actor", "Time"]} rows={(security?.auditLogs || []).map((log) => [log.action, log.actor?.username || "system", new Date(log.createdAt).toLocaleString()])} /></section><section className="glass rounded-lg p-5"><h2 className="mb-4 text-xl font-semibold">Sessions</h2><Table headers={["User", "IP", "Device", "Time"]} rows={(security?.sessions || []).map((session) => [session.user?.username || "-", session.ip || "-", session.userAgent || "-", new Date(session.createdAt).toLocaleString()])} /></section></div>;
}

function CrudLayout({ title, form, children }: { title: string; form: React.ReactNode; children: React.ReactNode }) {
  return <div className="space-y-4"><section className="glass rounded-lg p-5"><h2 className="mb-4 text-xl font-semibold">{title}</h2>{form}</section><section className="glass rounded-lg p-5">{children}</section></div>;
}

function Table({ headers, rows }: { headers: string[]; rows: React.ReactNode[][] }) {
  return <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left text-sm"><thead><tr className="border-b border-heron-line text-slate-400">{headers.map((header) => <th key={header} className="px-3 py-3 font-medium">{header}</th>)}</tr></thead><tbody>{rows.length ? rows.map((row, index) => <tr key={index} className="border-b border-white/[0.06]">{row.map((cell, cellIndex) => <td key={cellIndex} className="px-3 py-3 text-slate-200">{cell}</td>)}</tr>) : <tr><td className="px-3 py-8 text-slate-500" colSpan={headers.length}>No records yet</td></tr>}</tbody></table></div>;
}

function RowActions({ actions }: { actions: Array<[string, LucideIcon, () => void]> }) {
  return <div className="flex flex-wrap gap-2">{actions.map(([label, Icon, run]) => <button key={label} onClick={run} className="rounded-lg border border-heron-line bg-white/[0.04] px-3 py-2 text-xs text-slate-200 hover:text-heron-cyan"><Icon size={14} className="mr-1 inline" />{label}</button>)}</div>;
}

function input(label: string, value: string, onChange: (value: string) => void, type = "text") {
  return <label><span className="mb-2 block text-sm text-slate-300">{label}</span><input required className="w-full rounded-lg border border-heron-line bg-black/25 px-3 py-3 outline-none focus:border-heron-cyan" type={type} value={value} onChange={(event) => onChange(event.target.value)} /></label>;
}

function select(label: string, value: string, options: Array<[string, string]>, onChange: (value: string) => void) {
  return <label><span className="mb-2 block text-sm text-slate-300">{label}</span><select className="w-full rounded-lg border border-heron-line bg-black/25 px-3 py-3 outline-none focus:border-heron-cyan" value={value} onChange={(event) => onChange(event.target.value)}>{options.map(([optionValue, optionLabel]) => <option key={optionValue} value={optionValue}>{optionLabel}</option>)}</select></label>;
}
