# Deployment

## Docker

```bash
cp .env.example .env
docker compose up -d --build
```

## Cloudflare Tunnel

Create a Cloudflare Tunnel in Zero Trust and add a public hostname for your panel domain.

Use this service target in Cloudflare:

```text
http://web:3000
```

During HeronPanel first-run setup, paste either the tunnel token or the Docker command Cloudflare gives you, for example:

```bash
docker run cloudflare/cloudflared:latest tunnel --no-autoupdate run --token YOUR_TOKEN
```

HeronPanel stores the command, extracts the token, and starts a real `cloudflare/cloudflared` Docker container attached to the `heronpanel_default` Docker network.

## Ubuntu/Debian VPS

```bash
bash install.sh
```

The installer creates default runtime folders, generates secrets, starts PostgreSQL, Redis, API, web, and daemon services, then exposes:

- Web: `http://localhost:3000`
- API: `http://localhost:4000`

## Windows

Install Docker Desktop, enable WSL2 integration, then run:

```powershell
copy .env.example .env
docker compose up -d --build
```

## Cloud Platforms

HeronPanel works on AWS, Oracle Cloud, Azure, GCP, GitHub Codespaces, CodeSandbox, Replit, localhost, VPS, and dedicated servers as long as Docker or Node.js 20+ is available.
