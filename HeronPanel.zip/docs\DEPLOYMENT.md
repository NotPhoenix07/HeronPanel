# Deployment

## Docker

```bash
cp .env.example .env
docker compose up -d --build
```

## Ubuntu/Debian VPS

```bash
bash install.sh
```

The installer creates default runtime folders, generates secrets, starts PostgreSQL, Redis, API, web, and daemon services, then exposes:

- Web: `http://localhost:3000`
- API: `http://localhost:4000`

## Windows

Install Docker Desktop, enable WSL2 integration, then run:

```powershell
copy .env.example .env
docker compose up -d --build
```

## Cloud Platforms

HeronPanel works on AWS, Oracle Cloud, Azure, GCP, GitHub Codespaces, CodeSandbox, Replit, localhost, VPS, and dedicated servers as long as Docker or Node.js 20+ is available.
