import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HeronPanel",
  description: "Premium Self-Hosted Server Management Platform"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
