import { Router } from "express";
import { z } from "zod";
import { env } from "../env.js";
import { prisma } from "../prisma.js";
import { hashSecret, requireAuth, signToken, verifySecret } from "../security.js";

export const authRouter = Router();

authRouter.post("/login", async (request, response) => {
  const input = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(request.body);
  const user = await prisma.user.findUnique({ where: { email: input.email } });

  if (!user || !(await verifySecret(input.password, user.passwordHash))) {
    response.status(401).json({ message: "Invalid email or password" });
    return;
  }

  if (user.status !== "ACTIVE") {
    response.status(403).json({ message: "Account is pending approval, suspended, or banned" });
    return;
  }

  await prisma.session.create({
    data: {
      userId: user.id,
      ip: request.ip,
      userAgent: request.header("user-agent"),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    }
  });

  const token = signToken({ id: user.id, email: user.email, role: user.role, status: user.status });
  response.json({ token });
});

authRouter.post("/register", async (request, response) => {
  if (env.ALLOW_PUBLIC_REGISTRATION !== "true") {
    response.status(403).json({ message: "Public registration is disabled" });
    return;
  }

  const input = z.object({
    username: z.string().min(3).max(32),
    email: z.string().email(),
    password: z.string().min(8),
    firstName: z.string().min(1),
    lastName: z.string().min(1)
  }).parse(request.body);

  const user = await prisma.user.create({
    data: {
      username: input.username,
      email: input.email,
      passwordHash: await hashSecret(input.password),
      firstName: input.firstName,
      lastName: input.lastName,
      status: env.REQUIRE_REGISTRATION_APPROVAL === "true" ? "PENDING" : "ACTIVE"
    }
  });

  response.status(201).json({ id: user.id, status: user.status });
});

authRouter.get("/me", requireAuth, async (request, response) => {
  const user = await prisma.user.findUnique({
    where: { id: request.user!.id },
    select: { id: true, username: true, email: true, firstName: true, lastName: true, role: true, status: true }
  });
  response.json({ user });
});
