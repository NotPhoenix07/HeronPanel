import compression from "compression";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { ErrorRequestHandler } from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { createServer } from "http";
import { Server as SocketServer } from "socket.io";
import { env } from "./env.js";
import { authRouter } from "./routes/auth.js";
import { adminRouter } from "./routes/admin.js";
import { apiKeyRouter } from "./routes/api-keys.js";
import { fileRouter } from "./routes/files.js";
import { installerRouter } from "./routes/installer.js";
import { nodeRouter } from "./routes/nodes.js";
import { pluginRouter } from "./routes/plugins.js";
import { serverRouter } from "./routes/servers.js";
import { userRouter } from "./routes/users.js";

const app = express();
const httpServer = createServer(app);
const io = new SocketServer(httpServer, {
  cors: {
    origin: env.PANEL_URL,
    credentials: true
  }
});

app.set("trust proxy", 1);
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      connectSrc: ["'self'", env.PANEL_URL, "ws:", "wss:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"]
    }
  }
}));
app.use(cors({ origin: env.PANEL_URL, credentials: true }));
app.use(compression());
app.use(cookieParser(env.COOKIE_SECRET));
app.use(express.json({ limit: "2mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: true, legacyHeaders: false }));

app.get("/health", (_request, response) => {
  response.json({ ok: true, name: "HeronPanel API" });
});

app.use("/api/installer", installerRouter);
app.use("/api/auth", authRouter);
app.use("/api/admin", adminRouter);
app.use("/api/servers", serverRouter);
app.use("/api/nodes", nodeRouter);
app.use("/api/users", userRouter);
app.use("/api/files", fileRouter);
app.use("/api/api-keys", apiKeyRouter);
app.use("/api/plugins", pluginRouter);

io.on("connection", (socket) => {
  socket.on("server:join", (serverId: string) => socket.join(`server:${serverId}`));
  socket.on("server:console", ({ serverId, line }: { serverId: string; line: string }) => {
    io.to(`server:${serverId}`).emit("server:console", { line, at: new Date().toISOString() });
  });
  socket.on("node:stats", ({ nodeId, stats }: { nodeId: string; stats: unknown }) => {
    io.emit("node:stats", { nodeId, stats, at: new Date().toISOString() });
  });
});

const errorHandler: ErrorRequestHandler = (error, _request, response, _next) => {
  const message = error?.issues ? "Invalid request payload" : error?.message || "Internal server error";
  response.status(error?.status || 400).json({ message, details: error?.issues });
};

app.use(errorHandler);

httpServer.listen(env.API_PORT, () => {
  console.log(`HeronPanel API listening on :${env.API_PORT}`);
});
