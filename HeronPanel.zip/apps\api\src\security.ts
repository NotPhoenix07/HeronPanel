import bcrypt from "bcryptjs";
import jwt, { type Secret, type SignOptions } from "jsonwebtoken";
import { NextFunction, Request, Response } from "express";
import { env } from "./env.js";
import { prisma } from "./prisma.js";

export type AuthUser = {
  id: string;
  email: string;
  role: string;
  status: string;
};

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

export async function hashSecret(value: string) {
  return bcrypt.hash(value, 12);
}

export async function verifySecret(value: string, hash: string) {
  return bcrypt.compare(value, hash);
}

export function signToken(user: AuthUser) {
  const options: SignOptions = { expiresIn: env.JWT_EXPIRES_IN as SignOptions["expiresIn"] };
  return jwt.sign(user, env.JWT_SECRET as Secret, options);
}

export async function requireAuth(request: Request, response: Response, next: NextFunction) {
  const header = request.header("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;

  if (!token) {
    response.status(401).json({ message: "Authentication required" });
    return;
  }

  try {
    const payload = jwt.verify(token, env.JWT_SECRET) as AuthUser;
    const user = await prisma.user.findUnique({ where: { id: payload.id } });
    if (!user || user.status !== "ACTIVE") {
      response.status(401).json({ message: "Account is not active" });
      return;
    }
    request.user = { id: user.id, email: user.email, role: user.role, status: user.status };
    next();
  } catch {
    response.status(401).json({ message: "Invalid session" });
  }
}

export function requireRole(roles: string[]) {
  return (request: Request, response: Response, next: NextFunction) => {
    if (!request.user || !roles.includes(request.user.role)) {
      response.status(403).json({ message: "Permission denied" });
      return;
    }
    next();
  };
}
