#!/usr/bin/env bash
set -euo pipefail

HERON_API_URL="${HERON_API_URL:-}"
HERON_NODE_ID="${HERON_NODE_ID:-}"
HERON_NODE_TOKEN="${HERON_NODE_TOKEN:-}"

if [ -z "${HERON_API_URL}" ] || [ -z "${HERON_NODE_ID}" ] || [ -z "${HERON_NODE_TOKEN}" ]; then
  echo "Set HERON_API_URL, HERON_NODE_ID, and HERON_NODE_TOKEN before running."
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi

mkdir -p /etc/heron-daemon /var/lib/heron-daemon

cat >/etc/heron-daemon/daemon.env <<EOF
HERON_API_URL=${HERON_API_URL}
HERON_NODE_ID=${HERON_NODE_ID}
HERON_NODE_TOKEN=${HERON_NODE_TOKEN}
DOCKER_SOCKET=/var/run/docker.sock
EOF

cat >/etc/systemd/system/heron-daemon.service <<'EOF'
[Unit]
Description=HeronPanel Daemon
After=docker.service
Requires=docker.service

[Service]
EnvironmentFile=/etc/heron-daemon/daemon.env
WorkingDirectory=/opt/heronpanel/apps/daemon
ExecStart=/usr/bin/npm run start
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now heron-daemon
echo "Heron node daemon installed and started."
