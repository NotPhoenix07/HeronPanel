"use client";

import { useEffect, useState } from "react";
import { Dashboard } from "@/components/dashboard";
import { InstallerWizard } from "@/components/installer-wizard";
import { LoginPanel } from "@/components/login-panel";
import { api, InstallerStatus } from "@/lib/api";

export default function Home() {
  const [status, setStatus] = useState<InstallerStatus | null>(null);
  const [token, setToken] = useState<string | null>(() =>
    typeof window === "undefined" ? null : localStorage.getItem("heron_token")
  );

  useEffect(() => {
    api<InstallerStatus>("/installer/status")
      .then(setStatus)
      .catch(() => setStatus({ installed: false, panelName: "HeronPanel" }));
  }, []);

  if (!status) {
    return <div className="grid min-h-screen place-items-center text-slate-300">Booting HeronPanel...</div>;
  }

  if (!status.installed) {
    return <InstallerWizard onInstalled={() => setStatus({ installed: true, panelName: "HeronPanel" })} />;
  }

  if (!token) {
    return <LoginPanel onLogin={setToken} />;
  }

  return <Dashboard />;
}
