import { Router } from "express";
import { z } from "zod";
import { prisma } from "../prisma.js";
import { hashSecret, requireAuth, requireRole } from "../security.js";

export const userRouter = Router();

userRouter.use(requireAuth, requireRole(["OWNER", "ADMIN"]));

userRouter.get("/", async (_request, response) => {
  const users = await prisma.user.findMany({
    select: { id: true, username: true, email: true, firstName: true, lastName: true, role: true, status: true, createdAt: true }
  });
  response.json({ users });
});

userRouter.post("/", async (request, response) => {
  const input = z.object({
    username: z.string().min(3),
    email: z.string().email(),
    password: z.string().min(8),
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    role: z.enum(["OWNER", "ADMIN", "MODERATOR", "RESELLER", "USER"]).default("USER")
  }).parse(request.body);

  const { password, ...userInput } = input;
  const user = await prisma.user.create({
    data: {
      ...userInput,
      passwordHash: await hashSecret(password),
      status: "ACTIVE"
    }
  });

  response.status(201).json({ id: user.id });
});

userRouter.patch("/:id/status", async (request, response) => {
  const input = z.object({ status: z.enum(["PENDING", "ACTIVE", "SUSPENDED", "BANNED"]) }).parse(request.body);
  const user = await prisma.user.update({ where: { id: request.params.id }, data: { status: input.status } });
  response.json({ id: user.id, status: user.status });
});
