const API_URL = process.env.NEXT_PUBLIC_API_URL || "";

export type InstallerStatus = {
  installed: boolean;
  panelName: string;
};

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}/api${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {})
    },
    cache: "no-store"
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: "Request failed" }));
    const details = Array.isArray(error.details)
      ? `: ${error.details.map((detail: { path?: string[]; message?: string }) => `${detail.path?.join(".") || "field"} ${detail.message || "is invalid"}`).join(", ")}`
      : "";
    throw new Error(`${error.message || "Request failed"}${details}`);
  }

  return response.json() as Promise<T>;
}
