import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../security.js";

export const fileRouter = Router();

fileRouter.use(requireAuth);

fileRouter.get("/:serverId", (request, response) => {
  response.json({
    serverId: request.params.serverId,
    cwd: "/",
    files: [
      { name: "server.properties", type: "file", size: 1024, permissions: "rw-r--r--" },
      { name: "logs", type: "directory", size: 0, permissions: "rwxr-xr-x" }
    ]
  });
});

fileRouter.post("/:serverId/folder", (request, response) => {
  const input = z.object({ path: z.string().min(1), name: z.string().min(1) }).parse(request.body);
  response.status(201).json({ serverId: request.params.serverId, folder: input, queued: true });
});

fileRouter.post("/:serverId/extract", (request, response) => {
  const input = z.object({ archivePath: z.string().min(1), destination: z.string().min(1) }).parse(request.body);
  response.json({ serverId: request.params.serverId, extract: input, queued: true });
});
