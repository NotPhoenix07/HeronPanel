# HeronPanel

**Premium Self-Hosted Server Management Platform**

HeronPanel is a modern hosting control panel inspired by Pterodactyl, built around an easier installer, a premium responsive dashboard, secure auth, role-based access, server management, multi-node communication, Docker deployment, and future-friendly plugin/theme systems.

## Quick Start

```bash
cp .env.example .env
docker compose up -d
```

Or on Ubuntu/Debian:

```bash
bash install.sh
```

Then open `http://localhost:3000`. On first launch HeronPanel shows the setup wizard and creates the owner account.

## Apps

- `apps/web` - Next.js, React, TailwindCSS, Framer Motion, Recharts, Monaco-ready frontend.
- `apps/api` - Express, Socket.IO, Prisma, JWT, bcrypt, secure middleware, installer/auth/server/node APIs.
- `apps/daemon` - Heron Wings-style node daemon starter for container orchestration and telemetry.
- `packages/shared` - Shared roles, permissions, theme, and API types.

## Core Features

- First-run installer wizard
- JWT auth with bcrypt password hashing
- Owner/Admin/Moderator/User/Reseller roles
- Registration approval flow
- Server lifecycle APIs
- Node registration and heartbeat APIs
- Real-time Socket.IO console and stats channels
- Prisma schema for PostgreSQL/MySQL/SQLite-compatible development
- Docker Compose deployment
- Beginner-friendly install script
- Open-source ready docs and API reference

## Status

This repository is a production-oriented foundation. It includes the core application structure, security defaults, installer flow, database schema, Docker deployment, and extensibility surfaces. Real container execution, billing integrations, and marketplace publishing should be connected per infrastructure requirements before public hosting.
