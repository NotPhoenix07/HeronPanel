#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/heronpanel}"
REPO_URL="${REPO_URL:-}"

echo "HeronPanel installer"
echo "Target: ${APP_DIR}"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required. Install Docker Engine/Desktop, then rerun this script."
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose v2 is required."
  exit 1
fi

mkdir -p "${APP_DIR}"/{data,backups,logs,uploads}

if [ ! -f .env ]; then
  cp .env.example .env
  JWT_SECRET="$(openssl rand -hex 48 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  COOKIE_SECRET="$(openssl rand -hex 48 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  CSRF_SECRET="$(openssl rand -hex 48 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  ENCRYPTION_KEY="$(openssl rand -base64 32 2>/dev/null || date +%s%N | sha256sum | awk '{print $1}')"
  sed -i "s/JWT_SECRET=.*/JWT_SECRET=${JWT_SECRET}/" .env
  sed -i "s/COOKIE_SECRET=.*/COOKIE_SECRET=${COOKIE_SECRET}/" .env
  sed -i "s/CSRF_SECRET=.*/CSRF_SECRET=${CSRF_SECRET}/" .env
  sed -i "s#ENCRYPTION_KEY=.*#ENCRYPTION_KEY=${ENCRYPTION_KEY}#" .env
fi

docker compose up -d --build

echo ""
echo "HeronPanel is starting."
echo "Open http://localhost:3000 and complete the first-run setup wizard."
