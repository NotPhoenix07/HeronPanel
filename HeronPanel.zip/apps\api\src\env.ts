import "dotenv/config";
import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.string().default("development"),
  API_PORT: z.coerce.number().default(4000),
  PANEL_NAME: z.string().default("HeronPanel"),
  PANEL_URL: z.string().default("http://localhost:3000"),
  JWT_SECRET: z.string().default("development-only-change-me"),
  JWT_EXPIRES_IN: z.string().default("7d"),
  COOKIE_SECRET: z.string().default("development-cookie-secret"),
  ALLOW_PUBLIC_REGISTRATION: z.string().default("false"),
  REQUIRE_REGISTRATION_APPROVAL: z.string().default("true")
});

export const env = schema.parse(process.env);
