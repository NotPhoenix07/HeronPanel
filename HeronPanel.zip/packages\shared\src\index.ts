export const roles = ["OWNER", "ADMIN", "MODERATOR", "RESELLER", "USER"] as const;
export type Role = (typeof roles)[number];

export const permissions = {
  OWNER: ["*"],
  ADMIN: ["users.manage", "servers.manage", "nodes.manage", "settings.manage", "audit.read"],
  MODERATOR: ["users.read", "servers.read", "servers.power", "audit.read"],
  RESELLER: ["servers.create", "servers.read", "users.invite"],
  USER: ["servers.read", "servers.power", "files.manage", "console.read"]
} as const;

export const heronTheme = {
  name: "Heron Premium Dark",
  colors: {
    void: "#050712",
    panel: "#0a1020",
    panelSoft: "#111a33",
    cyan: "#30e7ff",
    violet: "#8b5cf6",
    blue: "#2563eb",
    text: "#f8fbff",
    muted: "#9aa9c7"
  }
};
