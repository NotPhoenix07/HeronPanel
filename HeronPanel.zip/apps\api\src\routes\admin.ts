import { Router } from "express";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../security.js";

export const adminRouter = Router();

adminRouter.use(requireAuth, requireRole(["OWNER", "ADMIN", "MODERATOR"]));

adminRouter.get("/summary", async (_request, response) => {
  const [users, servers, nodes, plugins, activeUsers, onlineServers, activeNodes] = await Promise.all([
    prisma.user.count(),
    prisma.server.count(),
    prisma.node.count(),
    prisma.plugin.count(),
    prisma.user.count({ where: { status: "ACTIVE" } }),
    prisma.server.count({ where: { status: "ONLINE" } }),
    prisma.node.count({ where: { isActive: true } })
  ]);

  response.json({
    users,
    servers,
    nodes,
    plugins,
    activeUsers,
    onlineServers,
    activeNodes,
    revenue: 0
  });
});

adminRouter.get("/database", async (_request, response) => {
  const [settings, auditLogs, sessions, apiKeys, allocations] = await Promise.all([
    prisma.setting.count(),
    prisma.auditLog.count(),
    prisma.session.count(),
    prisma.apiKey.count(),
    prisma.allocation.count()
  ]);

  response.json({
    provider: "postgresql",
    tables: [
      { name: "users", records: await prisma.user.count() },
      { name: "servers", records: await prisma.server.count() },
      { name: "nodes", records: await prisma.node.count() },
      { name: "settings", records: settings },
      { name: "audit_logs", records: auditLogs },
      { name: "sessions", records: sessions },
      { name: "api_keys", records: apiKeys },
      { name: "allocations", records: allocations }
    ]
  });
});

adminRouter.get("/security", async (_request, response) => {
  const [auditLogs, sessions, pendingUsers, bannedUsers] = await Promise.all([
    prisma.auditLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 25,
      include: { actor: { select: { username: true, email: true } } }
    }),
    prisma.session.findMany({
      orderBy: { createdAt: "desc" },
      take: 25,
      include: { user: { select: { username: true, email: true } } }
    }),
    prisma.user.count({ where: { status: "PENDING" } }),
    prisma.user.count({ where: { status: "BANNED" } })
  ]);

  response.json({ auditLogs, sessions, pendingUsers, bannedUsers });
});
