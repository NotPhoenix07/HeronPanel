import Docker from "dockerode";
import type { Readable } from "node:stream";
import { prisma } from "./prisma.js";

const docker = new Docker({ socketPath: process.env.DOCKER_SOCKET || "/var/run/docker.sock" });

type ServerForDocker = {
  id: string;
  name: string;
  type: string;
  image: string;
  memoryMb: number;
  cpuPercent: number;
};

function containerName(id: string) {
  return `heron-server-${id}`;
}

async function pullImage(image: string) {
  await new Promise<void>((resolve, reject) => {
    docker.pull(image, (error: Error | null, stream: Readable) => {
      if (error || !stream) {
        reject(error || new Error(`Unable to pull ${image}`));
        return;
      }
      docker.modem.followProgress(stream, (progressError) => {
        if (progressError) reject(progressError);
        else resolve();
      });
    });
  });
}

async function findContainer(name: string) {
  const containers = await docker.listContainers({ all: true });
  const found = containers.find((container) => container.Names.some((containerNameValue) => containerNameValue === `/${name}`));
  return found ? docker.getContainer(found.Id) : null;
}

function runtimeConfig(server: ServerForDocker) {
  const lowerType = server.type.toLowerCase();
  if (lowerType.includes("minecraft")) {
    return {
      Env: [`EULA=TRUE`, `MEMORY=${Math.max(512, server.memoryMb)}M`],
      Cmd: undefined
    };
  }

  return {
    Env: [`HERON_SERVER_ID=${server.id}`, `HERON_SERVER_NAME=${server.name}`],
    Cmd: ["sh", "-lc", "mkdir -p /data && cd /data && while true; do sleep 3600; done"]
  };
}

export async function startDockerServer(server: ServerForDocker) {
  const name = containerName(server.id);
  let container = await findContainer(name);

  if (!container) {
    await pullImage(server.image);
    const config = runtimeConfig(server);
    container = await docker.createContainer({
      name,
      Image: server.image,
      Tty: true,
      OpenStdin: true,
      Env: config.Env,
      Cmd: config.Cmd,
      Labels: {
        "heronpanel.server_id": server.id,
        "heronpanel.server_name": server.name
      },
      HostConfig: {
        Memory: server.memoryMb * 1024 * 1024,
        NanoCpus: Math.max(100_000_000, Math.floor((server.cpuPercent / 100) * 1_000_000_000)),
        RestartPolicy: { Name: "unless-stopped" },
        Binds: [`/app/data/servers/${server.id}:/data`]
      },
      WorkingDir: "/data"
    });
  }

  const details = await container.inspect();
  if (!details.State.Running) {
    await container.start();
  }
  return container.inspect();
}

export async function stopDockerServer(serverId: string) {
  const container = await findContainer(containerName(serverId));
  if (!container) return null;
  const details = await container.inspect();
  if (details.State.Running) await container.stop({ t: 10 });
  return container.inspect();
}

export async function deleteDockerServer(serverId: string) {
  const container = await findContainer(containerName(serverId));
  if (!container) return false;
  const details = await container.inspect();
  if (details.State.Running) await container.stop({ t: 10 });
  await container.remove({ force: true });
  return true;
}

export function extractCloudflareToken(commandOrToken: string) {
  const trimmed = commandOrToken.trim();
  const tokenMatch = trimmed.match(/(?:--token\s+|TUNNEL_TOKEN=)([A-Za-z0-9_\-.]+)/);
  return tokenMatch?.[1] || (trimmed.includes(" ") ? "" : trimmed);
}

export async function startCloudflareTunnel(commandOrToken: string) {
  const token = extractCloudflareToken(commandOrToken);
  if (!token) {
    throw new Error("Cloudflare tunnel token not found. Paste the token or docker command containing --token.");
  }

  const name = "heronpanel-cloudflared";
  let container = await findContainer(name);
  if (!container) {
    await pullImage("cloudflare/cloudflared:latest");
    container = await docker.createContainer({
      name,
      Image: "cloudflare/cloudflared:latest",
      Cmd: ["tunnel", "--no-autoupdate", "run", "--token", token],
      Labels: { "heronpanel.service": "cloudflare-tunnel" },
      HostConfig: {
        NetworkMode: process.env.CLOUDFLARE_DOCKER_NETWORK || "heronpanel_default",
        RestartPolicy: { Name: "unless-stopped" }
      }
    });
  }

  const details = await container.inspect();
  if (!details.State.Running) await container.start();
  await prisma.setting.upsert({ where: { key: "cloudflare_tunnel_status" }, update: { value: "running" }, create: { key: "cloudflare_tunnel_status", value: "running" } });
  return { token, details: await container.inspect() };
}
