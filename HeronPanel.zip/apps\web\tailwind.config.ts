import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        heron: {
          void: "#050712",
          ink: "#08111f",
          panel: "#0c1428",
          line: "rgba(120, 170, 255, 0.18)",
          cyan: "#30e7ff",
          violet: "#8b5cf6",
          blue: "#2563eb"
        }
      },
      boxShadow: {
        glow: "0 0 32px rgba(48, 231, 255, 0.22)",
        violet: "0 0 34px rgba(139, 92, 246, 0.24)"
      },
      backgroundImage: {
        "grid-glow":
          "linear-gradient(rgba(48,231,255,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,.08) 1px, transparent 1px)"
      }
    }
  },
  plugins: []
};

export default config;
