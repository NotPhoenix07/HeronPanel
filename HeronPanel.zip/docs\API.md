# HeronPanel API

Base URL: `http://localhost:4000/api`

Authentication uses `Authorization: Bearer <jwt>`.

## Installer

`GET /installer/status`

Returns whether the panel still needs first-run setup.

`POST /installer/setup`

Creates the owner account, writes secure runtime settings, and disables the installer.

## Auth

`POST /auth/login`

Body:

```json
{
  "email": "owner@example.com",
  "password": "password"
}
```

`POST /auth/register`

Creates a pending user when public registration is enabled.

`GET /auth/me`

Returns the authenticated user.

## Servers

`GET /servers`

Returns servers visible to the authenticated user.

`POST /servers`

Admin-only server creation.

`POST /servers/:id/power`

Body:

```json
{
  "signal": "start"
}
```

Supported signals: `start`, `stop`, `restart`, `kill`.

## Nodes

`POST /nodes`

Admin-only node registration.

`POST /nodes/:id/heartbeat`

Daemon heartbeat endpoint.

## WebSocket

Connect to Socket.IO at `ws://localhost:4000`.

Rooms:

- `server:<id>:console`
- `server:<id>:stats`
- `node:<id>:stats`

## Files

`GET /files/:serverId`

Lists files for a server. The current scaffold returns daemon-ready metadata and is designed for streaming upload, Monaco editing, ZIP extraction, permissions, rename, and delete actions.

## API Keys

`GET /api-keys`

Lists the current user's API keys.

`POST /api-keys`

Creates a scoped token and returns the raw token once.

## Plugins

`GET /plugins`

Admin-only plugin list.

`POST /plugins`

Registers a plugin manifest.
